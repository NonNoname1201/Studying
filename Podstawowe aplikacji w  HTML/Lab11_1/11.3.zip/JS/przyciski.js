
function saveProduct() {
    var product = document.getElementById("product").value;
    var price = document.getElementById("price").value;
    var color = document.getElementById("color").value;
    var quantity = document.getElementById("quantity").value;
    var productObject = {
        product: product,
        price: price,
        color: color,
        quantity: quantity
    };
    //5. Zmodyfikuj metodę dodawania produktów do localStorage – wykorzystaj możliwość
    //zapisu listy obiektów pod jednym kluczem (wykorzystaj przykład Organizer z wykładu).

    organizer = JSON.parse(localStorage.getItem("organizer"));
    if (organizer == null) {
        organizer = [];
        organizer.push(productObject);
    }else{
        organizer.push(productObject);
    }
    localStorage.setItem("organizer", JSON.stringify(organizer));
}

function displayBasket() {
    var table = document.getElementById("basketTable");


    table.innerHTML = "<tr><th style=\"width: 25%\">Nazwa produktu</th><th style=\"width: 25%\">Cena\t</th><th style=\"width: 25%\">Kolor</th><th style=\"width: 25%\">Liczba sztuk</th></tr>";

    var productsTemp = JSON.parse(localStorage.getItem("organizer"));

    for (var i = 0; i < productsTemp.length; i++) {
        table.innerHTML += "<tr><td>" + productsTemp[i].product + "</td><td>" + productsTemp[i].price + "</td><td>" + productsTemp[i].color + "</td><td>" + productsTemp[i].quantity + "</td></tr>";
    }
}

function deleteAll() {
    localStorage.setItem("organizer", JSON.stringify([]));
    localStorage.clear();
}